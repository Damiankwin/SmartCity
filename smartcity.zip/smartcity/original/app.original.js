// CÓDIGO ORIGINAL ENTREGADO (con errores intencionales). Solo para referencia/auditoría.
const express = require('express');
const app = express();
app.use(express.json());

let intersections = [
    { id: 1, name: 'Avenida Central', congestion: 40, light: 'green' },
    { id: 2, name: 'Bulevar Norte', congestion: 85, light: 'red' }
];

const TrafficModel = {
    getAll: () => intersections,
    findById: (id) => intersections.find(i => i.id === parseInt(id))
};

const TrafficService = {
    updateCongestion: (id, newCongestion) => {
        const intersection = TrafficModel.findById(id);
        
        intersection.congestion = newCongestion;

        if (newCongestion > 100) {
            intersection.light = 'green'; 
        } else if (newCongestion > 75) {
            intersection.light = 'yellow';
        } else {
            intersection.light = 'green';
        }
        return intersection;
    }
};

const TrafficController = {
    getIntersections: (req, res) => res.json(TrafficModel.getAll()),
    updateTraffic: (req, res) => {
        try {
            const result = TrafficService.updateCongestion(req.params.id, req.body.congestion);
            res.json(result);
        } catch (error) {
            res.status(400).json({ error: error.message });
        }
    }
};

app.get('/api/traffic', TrafficController.getIntersections);
app.put('/api/traffic/:id', TrafficController.updateTraffic);

module.exports = app;
